import { Product } from './../product/product';

import { ProductService } from './../../services/product.service';
import { Component, OnInit } from '@angular/core';
import { map } from 'rxjs/operators';




@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
  providers: [ProductService]
})
export class HomeComponent implements OnInit {

  products: Product[];
  pricefilter: Array<number> = [50, 100, 150];

  constructor(private productService: ProductService) { }

  ngOnInit(): void {

    this.productService.getAllProducts().pipe(map(res => res.products)).subscribe(data => {
     this.products = data;
    });


  }
}
