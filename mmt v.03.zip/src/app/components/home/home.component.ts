

import { CartService } from './../../services/cart.service';
import { ProductService } from './../../services/product.service';
import { Component, OnInit } from '@angular/core';

import { Router, ActivatedRoute } from '@angular/router';
import { Product, ProductResponse } from '../product/product';
import { CartModelServer } from 'src/app/models/cart.model';
import { stringify } from 'querystring';




@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
  providers: [ProductService]
})
export class HomeComponent implements OnInit {

  category: Array<any> = ['phone', 'electronic'];
  products: Product[];
  pricefilter: Array<number> = [50, 100, 150];
  cartData: CartModelServer;
  cartTotal: number;

  // tslint:disable-next-line:max-line-length
  constructor(private productService: ProductService, private router: Router, public cartservice: CartService, private activatedroute: ActivatedRoute) { }

  ngOnInit(): void {
    // Arka işlem servisinden gelen verileri ana component'e ürünler olarak yerleştirir.

    this.productService.getAllProducts().pipe().subscribe((data: ProductResponse) => {
      this.products = data.products;
    });

    this.cartservice.cartTotal$.subscribe(toplam => this.cartTotal = toplam);
    this.cartservice.cartDataObs$.subscribe(d => this.cartData = d);

  }
  // tslint:disable-next-line:typedef
  async delay(ms: number) {
    await new Promise(resolve => setTimeout(() => resolve(), ms)).then(() => console.log('fired'));
  }
  // Seçilen ürünün ayrıntılı bilgisinin bulunduğu comp. route edilir.
  selectProduct(id: number): void {
    this.delay(500).then(() => { this.router.navigate(['products/', id]).then(); });

  }
  // Seçilen ürünü sepete push eder.
  // tslint:disable-next-line:typedef
  addToCart(id: number) {
    this.cartservice.AddProductToCart(id);

  }
  // getSearchProduct(productName: string): void {
  //   this.router.navigate(['products/', i]).then();
  // }
  // tslint:disable-next-line:typedef
  filterCategory(catName: string) {
    this.productService.getProductsFromCategory(catName).subscribe(data => { this.products = data; });
  }
}
