import { CartService } from './../../services/cart.service';
import { Component, OnInit } from '@angular/core';
import { CartModelServer } from 'src/app/models/cart.model';
import { Product } from '../product/product';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.scss']
})
export class CheckoutComponent implements OnInit {
  products: Product[];
  cartData: CartModelServer;
  cartTotal: number;
  constructor(private cartservice: CartService) { }

  ngOnInit(): void {
    this.cartservice.cartTotal$.subscribe(toplam => this.cartTotal = toplam);
    this.cartservice.cartDataObs$.subscribe(d => this.cartData = d);
  }

}
