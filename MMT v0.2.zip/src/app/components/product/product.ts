import { JsonPipe } from '@angular/common';

export class Product{
    id: number;
    productName: string;
    price: number;
    quantity: number;
    category: string;
    description: string;
    // cat_id: number;
     imageUrl: string;
}

